package org.heartspores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeartsporesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
